#!/usr/bin/env node

const fs = require('fs');
const path = require('path');
const readlineSync = require('readline-sync');
const { URL } = require('url');
const process = require('process');
const MathModule = Math; // Using native Math

// ANSI Color codes
const Colors = {
    Green: "\x1b[32m",
    Red: "\x1b[31m",
    Bright: "\x1b[1m",
    Dim: "\x1b[2m",
    Purple: "\x1b[35m",
    Yellow: "\x1b[33m",
    Magenta: "\x1b[95m",
    Cyan: "\x1b[36m",
    Magenta2: "\x1b[91m",
    Blue: "\x1b[34m",
    Rainbow: "\x1b[38;5;206m",
    Gold: "\x1b[38;5;220m",
    Teal: "\x1b[38;5;51m",
    Orange: "\x1b[38;5;208m",
    Neon: "\x1b[38;5;198m",
    Electric: "\x1b[38;5;123m",
    RESET: "\x1b[0m"
};

// Helper function to print section headers
function print_section(title) {
    console.log(`\n${Colors.Bright}=== ${title} ===${Colors.RESET}\n`);
}

function CoderMark() {
  try {
    // Log multi-line string with preserved formatting and color codes
    console.log(`
    
 ______     __    __     ______     __         ______  
/\\  ___\\   /\\ "-./  \\   /\\  __ \\   /\\ \\       /\\  ___\\ ${Colors.Green}
\\ \\ \\____  \\ \\ \\-./\\ \\  \\ \\  __ \\  \\ \\ \\____  \\ \\  __\\ 
 \\ \\_____\\  \\ \\_\\ \\ \\_\\  \\ \\_\\ \\_\\  \\ \\_____\\  \\ \\_\\ ${Colors.Blue}  
  \\/_____/   \\/_/  \\/_/   \\/_/\\/_/   \\/_____/   \\/_/   ${Colors.Blue}${Colors.RESET}
                                                        
  
${Colors.Gold}[+] ${Colors.RESET}Bot Proxy Splitter ${Colors.Green}JS ${Colors.RESET} 
  
${Colors.Green}${"―".repeat(55)}
  
${Colors.Gold}[+]${Colors.RESET} DM : ${Colors.Teal}https://t.me/Djagocuan
  
${Colors.Gold}[+]${Colors.RESET} GH : ${Colors.Teal}https://github.com/cmalf/
    
${Colors.Green}${"―".repeat(55)}${Colors.RESET}
    `);
  } catch (error) {
    console.error("An error occurred while logging the banner:", error);
  }
}

function clean_proxy_line(line) {
    /*
    Cleans and validates a proxy line.
    Expected format: protocol://username:password@host:port
    Allowed protocols: http, https, socks4, socks5.
    If protocol is 'socks', it will be normalized to 'socks5'.
    */
    line = line.trim();
    if (!line || line.startsWith('#')) {
        return null;
    }

    try {
        let parsed = new URL(line);
        // Allowed schemes set
        let allowed_schemes = new Set(["http", "https", "socks", "socks4", "socks5"]);
        let scheme = parsed.protocol.replace(':', '').toLowerCase();
        if (!allowed_schemes.has(scheme)) {
            return null;
        }

        // Normalize 'socks' to 'socks5'
        if (scheme === "socks") {
            scheme = "socks5";
        }

        // Check required parts: username, password, hostname, port
        if (!parsed.username || !parsed.password || !parsed.hostname || !parsed.port) {
            return null;
        }

        // Rebuild and return normalized proxy URL
        let normalized_proxy = `${scheme}://${parsed.username}:${parsed.password}@${parsed.hostname}:${parsed.port}`;
        return normalized_proxy;
    } catch (error) {
        return null;
    }
}

function main() {
    console.clear();
    CoderMark();
    
    let script_dir = __dirname;
    let proxy_dir = path.join(script_dir, 'PROXY');
    let input_file = path.join(script_dir, 'all_proxies.txt');
    
    try {
        fs.mkdirSync(proxy_dir, { recursive: true });
    } catch (e) {
        console.log(`${Colors.Red}Error creating directory: ${e.toString()}${Colors.RESET}`);
        process.exit(1);
    }

    try {
        let fileContent = fs.readFileSync(input_file, { encoding: 'utf-8' });
        let proxies = [];
        fileContent.split('\n').forEach(function(line) {
            let proxy = clean_proxy_line(line);
            if (proxy) {
                proxies.push(proxy);
            }
        });
        
        let total_proxies = proxies.length;
        
        if (total_proxies === 0) {
            console.log(`${Colors.Red}Error: No valid proxies found in all_proxies.txt${Colors.RESET}`);
            console.log("➤ Make sure each proxy is on a new line in the format:");
            console.log("➤ protocol://username:password@host:port");
            console.log("➤ Allowed protocols: http, https, socks4, socks5");
            console.log("➤ If protocol is 'socks', it will be normalized to 'socks5'");
            console.log("➤ Example: http://555555-zone-custom-sessid-mL7zDXjI-sessTime-20:u5P05ssy@na.proxys5.net:6200");
            process.exit(1);
        }
        
        console.log(`\n${Colors.Green}➤ Total proxies found: ${Colors.Bright}${total_proxies}${Colors.RESET}`);
        console.log(`${Colors.Cyan}${'━'.repeat(50)}${Colors.RESET}\n`);
        
        print_section("OPTIONS");
        console.log(`${Colors.Bright}Please select an option:${Colors.RESET}\n`);
        console.log(`${Colors.Green}1. ${Colors.RESET}Specify proxies per file`);
        console.log(`${Colors.Green}2. ${Colors.RESET}Specify number of files`);
        
        let option = readlineSync.question(`\n${Colors.Yellow}Enter your choice (1/2): ${Colors.RESET}`);
        
        let proxies_per_file, total_files, total_needed;
        if (option === "1") {
            // Option 1: User specifies proxies per file
            try {
                let inputProxies = readlineSync.question(`${Colors.Yellow}How many proxies do you want in each file? (default: 10): ${Colors.RESET}`);
                proxies_per_file = parseInt(inputProxies || "10");
                if (proxies_per_file <= 0) {
                    console.log(`${Colors.Red}Number must be greater than 0. Using default: 10${Colors.RESET}`);
                    proxies_per_file = 10;
                }
                
                // Ask for the number of files to create
                try {
                    let inputFiles = readlineSync.question(`${Colors.Yellow}How many proxy files do you want to create? (proxy.txt, proxy1.txt, proxy2.txt, etc.): ${Colors.RESET}`);
                    let requested_files = parseInt(inputFiles);
                    if (requested_files <= 0) {
                        console.log(`${Colors.Red}Number must be greater than 0. Using calculated value based on available proxies.${Colors.RESET}`);
                        total_files = MathModule.ceil(total_proxies / proxies_per_file);
                    } else {
                        total_files = requested_files;
                    }
                } catch (err) {
                    console.log(`${Colors.Red}Invalid input. Using calculated value based on available proxies.${Colors.RESET}`);
                    total_files = MathModule.ceil(total_proxies / proxies_per_file);
                }
                
                total_needed = total_files * proxies_per_file;
                
            } catch (err) {
                console.log(`${Colors.Red}Invalid input. Using default: 10 proxies per file${Colors.RESET}`);
                proxies_per_file = 10;
                total_files = MathModule.ceil(total_proxies / proxies_per_file);
                total_needed = total_files * proxies_per_file;
            }
        
        } else if (option === "2") {
            // Option 2: User specifies number of files
            try {
                let inputFiles = readlineSync.question(`${Colors.Yellow}How many proxy files do you want to create? ${Colors.RESET}`);
                total_files = parseInt(inputFiles);
                if (total_files <= 0) {
                    console.log(`${Colors.Red}Number must be greater than 0. Using default: 10 files${Colors.RESET}`);
                    total_files = 10;
                }
                
                proxies_per_file = MathModule.ceil(total_proxies / total_files);
                total_needed = total_files * proxies_per_file;
                
            } catch (err) {
                console.log(`${Colors.Red}Invalid input. Using default: dividing into 10 files${Colors.RESET}`);
                total_files = 10;
                proxies_per_file = MathModule.ceil(total_proxies / total_files);
                total_needed = total_files * proxies_per_file;
            }
        
        } else {
            console.log(`${Colors.Red}Invalid option. Using default: 10 proxies per file${Colors.RESET}`);
            proxies_per_file = 10;
            total_files = MathModule.ceil(total_proxies / proxies_per_file);
            total_needed = total_files * proxies_per_file;
        }
        
        print_section("SUMMARY");
        console.log(`${Colors.Cyan}Total proxies available: ${Colors.Bright}${total_proxies}${Colors.RESET}`);
        console.log(`${Colors.Cyan}Proxies per file: ${Colors.Bright}${proxies_per_file}${Colors.RESET}`);
        console.log(`${Colors.Cyan}Total files to create: ${Colors.Bright}${total_files}${Colors.RESET}`);
        console.log(`${Colors.Cyan}Total proxies needed: ${Colors.Bright}${total_needed}${Colors.RESET}`);
        
        if (total_proxies < total_needed) {
            console.log(`${Colors.Red}${Colors.Bright}WARNING: ${Colors.RESET}${Colors.Red}You need ${total_needed - total_proxies} more proxies for even distribution${Colors.RESET}`);
        }
        
        let user_confirmation = readlineSync.question(`\n${Colors.Yellow}${Colors.Bright}Do you want to proceed? (y/n): ${Colors.RESET}`);
        if (!["y", "yes"].includes(user_confirmation.toLowerCase())) {
            console.log(`${Colors.Red}Operation cancelled${Colors.RESET}`);
            process.exit(0);
        }
        
        // Create the proxy files
        console.log(`\n${Colors.Green}Processing...${Colors.RESET}`);
        let progress_chars = ["⣾", "⣽", "⣻", "⢿", "⡿", "⣟", "⣯", "⣷"];
        
        for (let i = 0; i < total_files; i++) {
            // Show progress
            let progress = parseInt((i / total_files) * 100);
            let progress_char = progress_chars[i % progress_chars.length];
            process.stdout.write(`${Colors.Cyan}Progress: ${progress}% ${progress_char}${Colors.RESET}\r`);
            
            let start_idx = i * proxies_per_file;
            let end_idx = Math.min(start_idx + proxies_per_file, total_proxies);
            
            // Use 'proxy.txt' for the first file, then 'proxy1.txt', 'proxy2.txt', etc.
            let filename = "";
            if (i === 0) {
                filename = path.join(proxy_dir, 'proxy.txt');
            } else {
                filename = path.join(proxy_dir, `proxy${i}.txt`);
            }
            
            try {
                let chunk = proxies.slice(start_idx, end_idx);
                let fileData = "";
                chunk.forEach(function(proxy) {
                    fileData += proxy + '\n';
                });
                fs.writeFileSync(filename, fileData, { encoding: 'utf-8' });
            } catch (err) {
                console.log(`${Colors.Red}Error writing to file ${filename}: ${err.toString()}${Colors.RESET}`);
                continue;
            }
        }
        
        // Clear progress line
        process.stdout.write(' '.repeat(80) + '\r');
        
        print_section("OPERATION COMPLETE");
        console.log(`${Colors.Green}${Colors.Bright}✓ ${Colors.RESET}${Colors.Green}Created ${Colors.Bright}${total_files}${Colors.RESET}${Colors.Green} proxy files with ${Colors.Bright}${proxies_per_file}${Colors.RESET}${Colors.Green} proxies each (when possible)${Colors.RESET}`);
        console.log(`${Colors.Green}${Colors.Bright}✓ ${Colors.RESET}${Colors.Green}Files are stored in the '${Colors.Bright}${proxy_dir}${Colors.RESET}${Colors.Green}' directory${Colors.RESET}`);
        console.log(`\n${Colors.Magenta}${Colors.Bright}Thank you for using PROXY SPLITTER By CMALF!${Colors.RESET}`);
        console.log(`${Colors.Yellow}${'★'.repeat(60)}${Colors.RESET}`);
    
    } catch (err) {
        if (err.code === 'ENOENT') {
            console.log(`${Colors.Red}Error: Please create '${input_file}' file first and add your proxies to it${Colors.RESET}`);
            console.log("➤ Each proxy should be on a new line in the format:");
            console.log("➤ protocol://username:password@host:port");
            console.log("➤ Allowed protocols: http, https, socks4, socks5");
            console.log("➤ If protocol is 'socks', it will be normalized to 'socks5'");
            console.log("➤ Example: http://555555-zone-custom-sessid-mL7zDXjI-sessTime-20:u5P05ssy@na.proxys5.net:6200");
            process.exit(1);
        } else {
            console.log(`${Colors.Red}Error occurred: ${err.toString()}${Colors.RESET}`);
            console.log("Please check that your all_proxies.txt file is properly formatted");
            process.exit(1);
        }
    }
}

if (require.main === module) {
    main();
}
