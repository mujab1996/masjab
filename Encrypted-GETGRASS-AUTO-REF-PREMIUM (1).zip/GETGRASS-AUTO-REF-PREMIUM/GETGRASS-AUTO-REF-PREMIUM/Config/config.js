/* ---------- config.js ---------- */
"use strict";

const choice = {
  c1: "capmonster", // https://capmonster.cloud/
  c2: "2captcha",   // https://2captcha.com/
  c3: "anticaptcha" // https://anti-captcha.com/
};

const CAPTCHA_Data = {
  sitekey: "6LeeT-0pAAAAAFJ5JnCpNcbYCBcAerNHlkK4nm6y",
  CAPMONSTER_API_KEY: "YOUR_CAPMONSTER_API_KEY",
  TWO_CAPTCHA_API_KEY: "YOUR_2CAPTCHA_API_KEY",
  ANTICAPTCHA_API_KEY: "YOUR_ANTICAPTCHA_API_KEY"
};

const RefCode = {
  ref1: "13-CMALF",
  ref2: "XXXXXXXX",
  ref3: "XXXXXXXX"
  // You can add more referral codes here 
};

let SelectedRefCode = RefCode.ref1; // default value; updated based on user selection

const ServiceChoice = choice.c1; // Change to your desired service: c1, c2, or c3

// Construct the captcha URL using the selected referral code (just ignore this one!)
const captcha_url = `https://app.getgrass.io/register/${SelectedRefCode}`;

module.exports = { CAPTCHA_Data, ServiceChoice, RefCode, SelectedRefCode, captcha_url };